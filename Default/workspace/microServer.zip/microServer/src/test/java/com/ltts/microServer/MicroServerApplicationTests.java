package com.ltts.microServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
